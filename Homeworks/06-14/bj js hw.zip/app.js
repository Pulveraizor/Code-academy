let bud = prompt ('Iveskite bazinio uzmokescio dydi');
document.write((1761463*bud)/84873000);